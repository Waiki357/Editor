#include "notepadwindow.h"

NotepadWindow::NotepadWindow(QWidget *parent)
    : QMainWindow(parent)
{
    //Establecemos el tamaño inicial de la ventana
    this->setGeometry(30, 30, 800, 600);

    //Establecemos el título de la ventana
    this->setWindowTitle(tr("Super editor de texto"));

    //Inicializamos los menús
    mainMenu_ = new QMenuBar(this);

    mnuArchivo_ = new QMenu(tr("&Archivo"), this);
    mainMenu_->addMenu(mnuArchivo_);

    actArchivoAbrir_ = new QAction(tr("&Abrir"), this);
    actArchivoAbrir_->setShortcut(QKeySequence(Qt::CTRL + Qt::Key_O));
    mnuArchivo_->addAction(actArchivoAbrir_);

    actArchivoGuardar_ = new QAction(tr("&Guardar"), this);
    actArchivoGuardar_->setShortcut(QKeySequence(Qt::CTRL + Qt::Key_S));
    mnuArchivo_->addAction(actArchivoGuardar_);

    //Salir
    actArchivoSalir_ = new QAction(tr("&Salir"),this);
    mnuArchivo_->addAction(actArchivoSalir_);

    mnuEditar_ = new QMenu(tr("&Editar"), this);
    mainMenu_->addMenu(mnuEditar_);

    //Cortar
    actEditarCortar_ = new QAction(tr("&Cortar"), this);
    actEditarCortar_->setShortcut(QKeySequence(Qt::CTRL + Qt::Key_X));
    mnuEditar_->addAction(actEditarCortar_);

    //Deshacer
    actEditarDeshacer_ = new QAction(tr("&Deshacer"), this);
    actEditarDeshacer_->setShortcut(QKeySequence(Qt::CTRL + Qt::Key_Z));
    mnuEditar_->addAction(actEditarDeshacer_);

    //Rehacer
    actEditarRehacer_ = new QAction(tr("&Rehacer"), this);
    actEditarRehacer_->setShortcut(QKeySequence(Qt::CTRL + Qt::Key_Y));
    mnuEditar_->addAction(actEditarRehacer_);

    actEditarCopiar_ = new QAction(tr("&Copiar"), this);
    actEditarCopiar_->setShortcut(QKeySequence(Qt::CTRL + Qt::Key_C));
    mnuEditar_->addAction(actEditarCopiar_);

    actEditarPegar_ = new QAction(tr("&Pegar"), this);
    actEditarPegar_->setShortcut(QKeySequence(Qt::CTRL + Qt::Key_V));
    mnuEditar_->addAction(actEditarPegar_);

    mnuFormato_ = new QMenu(tr("&Formato"), this);
    mainMenu_->addMenu(mnuFormato_);

    //Ayuda
    mnuAyuda_ = new QMenu(tr("&Ayuda"),this);
    mainMenu_->addMenu(mnuAyuda_);

    actAyudaAcerca_ = new QAction(tr("&Acerca de"), this);
    mnuAyuda_->addAction(actAyudaAcerca_);

    actFormatoFuente_ = new QAction(tr("&Fuente"), this);
    mnuFormato_->addAction(actFormatoFuente_);

    //Agregamos la barra de menú a la ventana
    this->setMenuBar(mainMenu_);

    //Barra

    toolbar_ = addToolBar(tr("&Herramientas"));

    actCopiar_ = toolbar_->addAction(QIcon("/home/siga01.stic.ull.es/da/alu0100918540/Descargas/Qt_CodigoBase_Editor-master/curso-qt-osl-notepad/Resources/copy.jpg"),"Copiar");
    toolbar_->addSeparator();
    actCortar_ = toolbar_->addAction(QIcon("/home/siga01.stic.ull.es/da/alu0100918540/Descargas/Qt_CodigoBase_Editor-master/curso-qt-osl-notepad/Resources/cut.png"),"Cortar");
    toolbar_->addSeparator();
    actPegar_ = toolbar_->addAction(QIcon("/home/siga01.stic.ull.es/da/alu0100918540/Descargas/Qt_CodigoBase_Editor-master/curso-qt-osl-notepad/Resources/paste.jpg"),"Pegar");
    toolbar_->addSeparator();

    //Negrita Subrayado ....
    actSub_ = toolbar_->addAction(QIcon("/home/siga01.stic.ull.es/da/alu0100918540/Descargas/Qt_CodigoBase_Editor-master/curso-qt-osl-notepad/Resources/sub.png"),"Subrayado");
    toolbar_->addSeparator();
    actCur_ = toolbar_->addAction(QIcon("/home/siga01.stic.ull.es/da/alu0100918540/Descargas/Qt_CodigoBase_Editor-master/curso-qt-osl-notepad/Resources/cur.png"),"Cursiva");
    toolbar_->addSeparator();
    actNeg_ = toolbar_->addAction(QIcon("/home/siga01.stic.ull.es/da/alu0100918540/Descargas/Qt_CodigoBase_Editor-master/curso-qt-osl-notepad/Resources/bold.png"),"Negrita");
    toolbar_->addSeparator();


    //Inicializamos el editor de texto
    txtEditor_ = new QTextEdit(this);

    //Conectamos las acciones de los menús con nuestros slots
    connect(actArchivoAbrir_,   SIGNAL(triggered()), this,          SLOT(alAbrir()));
    connect(actArchivoGuardar_, SIGNAL(triggered()), this,          SLOT(alGuardar()));
    connect(actEditarCopiar_,   SIGNAL(triggered()), txtEditor_,    SLOT(copy()));
    connect(actEditarPegar_,    SIGNAL(triggered()), txtEditor_,    SLOT(paste()));
    connect(actFormatoFuente_,  SIGNAL(triggered()), this,          SLOT(alFuente()));
    connect(actArchivoSalir_,   SIGNAL(triggered()), this,          SLOT(alSalir()));
    connect(actEditarCortar_,   SIGNAL(triggered()), txtEditor_,    SLOT(cut()));
    connect(actEditarDeshacer_,   SIGNAL(triggered()), txtEditor_,  SLOT(redo()));
    connect(actEditarRehacer_,   SIGNAL(triggered()), txtEditor_,   SLOT(undo()));
    connect(actAyudaAcerca_,   SIGNAL(triggered()), this,   SLOT(onAcerca()));
    connect(actCopiar_,   SIGNAL(triggered()), txtEditor_,   SLOT(copy()));
    connect(actPegar_,   SIGNAL(triggered()), txtEditor_,   SLOT(paste()));
    connect(actCortar_,   SIGNAL(triggered()), txtEditor_,   SLOT(cut()));
    connect(actCur_,   SIGNAL(triggered()), this,   SLOT(onCursiva()));
    connect(actSub_,   SIGNAL(triggered()), this,   SLOT(onSubrayado()));
    connect(actNeg_,   SIGNAL(triggered()), this,   SLOT(onNegrita()));

    //Agregamos el editor de texto a la ventana
    this->setCentralWidget(txtEditor_);
}

NotepadWindow::~NotepadWindow()
{
    //Liberamos los recursos
    mainMenu_->deleteLater();
    actArchivoAbrir_->deleteLater();
    actArchivoGuardar_->deleteLater();
    mnuArchivo_->deleteLater();
    actEditarCopiar_->deleteLater();
    actEditarPegar_->deleteLater();
    mnuEditar_->deleteLater();
    actFormatoFuente_->deleteLater();
    mnuFormato_->deleteLater();
    txtEditor_->deleteLater();
}

void NotepadWindow::alAbrir()
{
    //Mostramos un dialogo de apertura de ficheros y almacenamos la selección (ruta) en una variable
    QString nombreArchivo;
    nombreArchivo = QFileDialog::getOpenFileName(this,
                                                 tr("Abrir archivo de texto plano"),
                                                 "",
                                                 tr("Archivos de texto plano (*.txt)"));
    if (nombreArchivo != "") {
        //Intentamos abrir el archivo
        QFile archivo;
        archivo.setFileName(nombreArchivo);
        if (archivo.open(QFile::ReadOnly)) {
            //Si se pudo abrir el archivo, lo leemos y colocamos su contenido en nuestro editor
            //txtEditor_->setPlainText(archivo.readAll());
            txtEditor_->setText(archivo.readAll());
            //Se cierra el fichero
            archivo.close();
        }
    }
}

void NotepadWindow::alGuardar()
{
    //Mostramos un dialogo de guardado de ficheros y almacenamos la selección (ruta) en una variable
    QString nombreArchivo;
    nombreArchivo = QFileDialog::getSaveFileName(this,
                                                 tr("Guardar archivo de texto plano"),
                                                 "",
                                                 tr("Archivos de texto plano (*.txt)"));
    if (nombreArchivo != "") {
        //Intentamos abrir el archivo
        QFile archivo;
        archivo.setFileName(nombreArchivo + ".txt");
        if (archivo.open(QFile::WriteOnly | QFile::Truncate)) {
            //Si se pudo abrir el archivo, escribimos el contenido del editor
            archivo.write(txtEditor_->toHtml().toUtf8());
            //Se cierra el fichero
            archivo.close();
        }
    }
}

void NotepadWindow::alSalir(){
    this->close();
}

void NotepadWindow::onCursiva(){

    if(txtEditor_->fontItalic())
        txtEditor_->setFontItalic(false);
    else
        txtEditor_->setFontItalic(true);
}

void NotepadWindow::onSubrayado(){

    if(txtEditor_->fontUnderline())
        txtEditor_->setFontUnderline(false);
    else
        txtEditor_->setFontUnderline(true);
}

void NotepadWindow::onNegrita(){

    if (txtEditor_->fontWeight() == QFont::Bold)
        txtEditor_->setFontWeight(QFont::Normal);
    else
        txtEditor_->setFontWeight(QFont::Bold);
}

void NotepadWindow::onAcerca(){
    QMessageBox::information(this,tr("Super Editor De Texto"),tr("Jorge Gutierrez Reyes") );
}
void NotepadWindow::alFuente()
{
    bool ok;
    QFont font = QFontDialog::getFont(&ok, txtEditor_->font(), this);
    if (ok) {
        // Si el usuario hizo click en OK, se establece la fuente seleccionada
        txtEditor_->setFont(font);
    }
}
